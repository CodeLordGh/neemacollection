import express, {Application} from "express";
import mongoose from "mongoose";
import session from 'express-session';
import passport from "./utils/auth.strategy";
import cors from "cors";
import * as dotenv from "dotenv";
import orderRouter from "./routes/order.route";
import flash from "connect-flash";
import http from "http"
import {Server} from "socket.io";
import router from "./routes/auth.route";
import cookieParser from "cookie-parser";
import productRoute from "./routes/product.route";
import { Product } from "./Models/product.model";

dotenv.config(); // Load environment variables from .env

const app: Application = express();
const port = process.env.PORT || 3000

const server = http.createServer(app)

const db_connect = `mongodb+srv://${process.env.DB_USERNAME}:${process.env.DB_PASSWORD}@neema.acaijrr.mongodb.net/?retryWrites=true&w=majority&appName=Neema`;
const io = new Server (server, {
  cors: {
    origin:"http://localhost:5173",
    methods: "GET",
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"],
  }
})

app.use(express.json());
app.use(cors())
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser())

app.use(session({
  name: 'jwt',
  secret: process.env.COOKIE_SECRET as string || 'secret',
  resave: true,
  saveUninitialized: false,
}));

// setore error messages in session
app.use(flash())

app.use(passport.initialize());
app.use(passport.session());

// Error handling middleware
app.use((err: any, req: any, res: any, next: any) => {
  if (err) {
    const message = err.message || 'Unauthorized';
    res.status(401).send(message);
  }
  next()
});

app.use("/api", router);
app.use("/api", productRoute)
app.use("/api", orderRouter)

io.on("connection", socket => {
  console.log(`connected: ${socket.id}`);
  // Listen for the 'get_all_products' event from the frontend
  socket.on("get_all_products", async ({ authorization }) => {
    try {
      // Extract the token from the request data
      const token = authorization?.split(" ")[1];

      if (!token) {
        socket.emit("get_all_products_response", { message: "Unauthorized" });
        return;
      }
      
      // Verify the token using Passport.js
      await passport.authenticate("jwt", { session: false }, async (err:any, user:any) => {
        if (err || !user) {
          console.log(err);
          socket.emit("get_all_products_response", { message: "Unauthorized" });
          return;
        }

        try {
          const products = await Product.find({});
          console.log(`server line 94 products is ${products}`)
          if (products.length === 0) {
            socket.emit("get_all_products_response", { message: "No products found" });
          } else {
            socket.emit("get_all_products_response", products);
          }
        } catch (error) {
          socket.emit("get_all_products_response", { message: "Error retrieving products" });
        }
      })(
        {
          headers: { authorization },
        }
      );
    } catch (error) {
      console.log(error);
      socket.emit("get_all_products_response", { message: "Error retrieving products" });
    }
  });

  socket.on("disconnect", () => console.log("User disconnected", socket.id))
})

mongoose.connect(db_connect)
.then(() => console.log("Connected to MongoDB"))
.then(() => server.listen(3001))
.then(() => app.listen(port, () => {
    console.log(`Server running on port ${port} http://localhost:${process.env.PORT}`);
}))
.catch(error => console.error("Error connecting to MongoDB:", error));


export default app;
