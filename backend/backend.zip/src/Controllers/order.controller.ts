import { Request, Response } from "express";
import { order as Order, IOrder } from "../Models/order.model";
import { Product } from "../Models/product.model";
import mongoose from "mongoose";

/**
 * Creates a new order with the provided products for the authenticated user.
 *
 * @param {Request} req - The HTTP request object containing the user and products.
 * @param {Response} res - The HTTP response object to send the result.
 * @return {Promise<void>} A promise that resolves when the order is created successfully or rejects with an error.
 */
export const createOrder = async (req: any, res: Response) => {
    try {
        const user = req.user._id;
        const { products } = req.body;


        // Calculate the total amount
        let totalPrice = 0;
        const productQuantities: { [key: string]: number } = {};
        for (const product of products) {
          const productId = product.product;
          const quantity = product.quantity;
    
          // Find the product by ID
          const productDoc = await Product.findById(productId);
    
          if (!productDoc) {
            return res.status(404).json({ message: 'Product not found' });
          }
    
          // Check if the user can buy all the quantity
          if (quantity > productDoc.quantity) {
            return res.status(400).json({ message: 'Order quantity exceeds product quantity' });
          }
    
          // Update the product quantities object
          productQuantities[productId] = quantity;
          // total price of a product
          product.price = quantity * productDoc.price;

          // Calculate the total amount
          totalPrice += product.price
        }
    
        // Create a new order
        const newOrder = new Order({
          user,
          products: products.map((product: any) => ({
            product: product.product,
            quantity: product.quantity,
            price: product.price
          })),
          totalPrice,
        });
    
        // Start a transaction
        const session = await mongoose.startSession();
        session.startTransaction();
    
        try {
          // Save the new order
          await newOrder.save({ session });
    
          // Update the product quantities
          for (const productId of Object.keys(productQuantities)) {
            const productDoc = await Product.findById(productId);
            if (productDoc) {
              productDoc.quantity -= productQuantities[productId];
              await productDoc.save({ session });
            }
          }
    
          // Commit the transaction
          await session.commitTransaction();
        } catch (error) {
          // Abort the transaction if either operation fails
          await session.abortTransaction();
          throw error;
        } finally {
          // End the session
          session.endSession();
        }
    
        res.status(201).json({ message: 'Order placed successfully', order: newOrder });
      } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
      }
};

/**
 * Retrieves all orders for the authenticated user.
 *
 * @param {Request} req - The HTTP request object containing the authenticated user.
 * @param {Response} res - The HTTP response object to send the result.
 * @return {Promise<void>} A promise that resolves when the orders are retrieved successfully or rejects with an error.
 */
export const getOrders = async (req: any, res: Response) => {
  try {
    const orders: IOrder[] = await Order.find({ user: req.user?._id });

    orders.length === 0 ? res.status(404).json({ message: "You have no orders for now!" }) : res.status(200).json({ message: "Orders retrieved successfully", orders });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * Updates an order by its ID with the provided data.
 *
 * @param {Request} req - The HTTP request object containing the order ID and updated data.
 * @param {Response} res - The HTTP response object to send the result.
 * @return {Promise<void>} A promise that resolves when the order is updated successfully or rejects with an error.
 */
export const updateOrder = async (req: Request, res: Response) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, req.body, { new: true })!;

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    res.status(200).json({ message: "Order updated successfully", order });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};
/**
 * Retrieves a specific order by its ID.
 *
 * @param {Request} req - The HTTP request object containing the order ID.
 * @param {Response} res - The HTTP response object to send the result.
 * @return {Promise<void>} A promise that resolves when the order is retrieved successfully or rejects with an error.
 */
export const getOderById = async (req: Request, res: Response) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    res.status(200).json({ message: "Order retrieved successfully", order });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
}
/**
 * Deletes an order by its ID.
 *
 * @param {Request} req - The HTTP request object containing the order ID.
 * @param {Response} res - The HTTP response object to send the result.
 * @return {Promise<void>} A promise that resolves when the order is deleted successfully or rejects with an error.
 */
export const deleteOrder = async (req: Request, res: Response) => {
  try {
    const order = await Order.findByIdAndDelete(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    res.status(200).json({ message: "Order deleted successfully", order });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};